<?php
include 'includes/functions.php';
include 'includes/header.php';

// Array of courses
$courses = [
    'bsc-it' => [
        'title' => 'B.Sc. Information Technology',
        'duration' => '3 Years',
        'description' => 'A 3-year undergraduate program focusing on IT fundamentals, programming, and software development.',
        'eligibility' => '12th Pass with Mathematics',
        'career' => 'Software Developer, System Analyst, Database Administrator'
    ],
    'bcom' => [
        'title' => 'B.Com',
        'duration' => '3 Years',
        'description' => 'Bachelor of Commerce with focus on accounting, finance, and business principles.',
        'eligibility' => '12th Pass in any stream',
        'career' => 'Accountant, Financial Analyst, Auditor'
    ],
    'bms' => [
        'title' => 'BMS (Bachelor of Management Studies)',
        'duration' => '3 Years',
        'description' => 'Management-oriented program that prepares students for corporate leadership roles.',
        'eligibility' => '12th Pass in any stream',
        'career' => 'Business Analyst, HR Manager, Marketing Executive'
    ]
];

// Get course key from URL
$course_key = isset($_GET['course']) ? sanitize_input($_GET['course']) : null;
$course = $courses[$course_key] ?? null;
?>

<main class="container mx-auto px-6 py-10">
    <?php if ($course): ?>
        <h1 class="text-3xl font-bold text-blue-700 mb-4"><?php echo $course['title']; ?></h1>
        <p class="text-gray-700 mb-2"><strong>Duration:</strong> <?php echo $course['duration']; ?></p>
        <p class="text-gray-700 mb-2"><strong>Eligibility:</strong> <?php echo $course['eligibility']; ?></p>
        <p class="text-gray-700 mb-4"><strong>Description:</strong> <?php echo $course['description']; ?></p>
        <p class="text-gray-700 mb-4"><strong>Career Opportunities:</strong> <?php echo $course['career']; ?></p>
        <a href="admission.php" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Apply Now</a>
    <?php else: ?>
        <h2 class="text-2xl text-red-600">Course not found!</h2>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
