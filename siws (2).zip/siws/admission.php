<?php
include 'includes/functions.php';
include 'includes/header.php';

$name = $email = $course = "";
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $course = sanitize_input($_POST['course']);

    if (empty($name)) $errors[] = "Name is required.";
    if (empty($email) || !validate_email($email)) $errors[] = "Valid email is required.";
    if (empty($course)) $errors[] = "Please select a course.";

    if (empty($errors)) {
        // Normally, save to DB or send email
        $success = "Thank you, $name! Your admission request for $course has been submitted.";
    }
}
?>

<main class="container mx-auto px-6 py-10">
    <h1 class="text-3xl font-bold text-blue-700 mb-4">Admission Form</h1>

    <?php if (!empty($errors)): ?>
        <div class="bg-red-100 text-red-700 p-4 mb-4 rounded">
            <?php foreach ($errors as $error) echo "<p>$error</p>"; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="bg-green-100 text-green-700 p-4 mb-4 rounded"><?php echo $success; ?></div>
    <?php endif; ?>

    <form method="post" action="" class="bg-white shadow-md p-6 rounded space-y-4">
        <div>
            <label class="block mb-1 font-medium">Name:</label>
            <input type="text" name="name" value="<?php echo $name; ?>" class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block mb-1 font-medium">Email:</label>
            <input type="email" name="email" value="<?php echo $email; ?>" class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block mb-1 font-medium">Course:</label>
            <select name="course" class="w-full border rounded px-3 py-2">
                <option value="">Select a course</option>
                <option value="B.Sc IT" <?php if($course=="B.Sc IT") echo "selected"; ?>>B.Sc IT</option>
                <option value="B.Com" <?php if($course=="B.Com") echo "selected"; ?>>B.Com</option>
                <option value="BMS" <?php if($course=="BMS") echo "selected"; ?>>BMS</option>
            </select>
        </div>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Submit</button>
    </form>
</main>

<?php include 'includes/footer.php'; ?>
