<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIWS College - Excellence in Education</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            scroll-behavior: smooth;
        }
        .hero-gradient {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 50%, #60a5fa 100%);
        }
        .course-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #1e40af, #3b82f6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Header & Navigation -->
    <?php include 'includes/navigation.php'; ?>

    <!-- Hero Section -->
    <section id="home" class="hero-gradient text-white py-20">
        <div class="container mx-auto px-6">
            <div class="flex flex-col md:flex-row items-center">
                <div class="md:w-1/2 mb-10 md:mb-0">
                    <h2 class="text-4xl md:text-5xl font-bold mb-6">Shaping Future Leaders Through Excellence in Education</h2>
                    <p class="text-xl mb-8 opacity-90">Join SIWS College for a transformative educational experience that prepares you for success in the modern world.</p>
                    <div class="flex space-x-4">
                        <a href="admission.php" class="bg-white text-blue-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition duration-300">
                            Apply Now
                        </a>
                        <a href="#courses" class="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-blue-600 transition duration-300">
                            Explore Courses
                        </a>
                    </div>
                </div>
                <div class="md:w-1/2">
                    <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/3222bb18-5884-4b23-813c-4f1ef6dee211.png" alt="Modern college campus building with students walking between classes during sunny day" class="rounded-lg shadow-2xl" />
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="bg-white py-16">
        <div class="container mx-auto px-6">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <?php
                $stats = [
                    ['number' => '5000+', 'label' => 'Students'],
                    ['number' => '150+', 'label' => 'Faculty'],
                    ['number' => '25+', 'label' => 'Courses'],
                    ['number' => '15+', 'label' => 'Years']
                ];
                
                foreach ($stats as $stat) {
                    echo '<div class="p-6">
                        <div class="stat-number">' . $stat['number'] . '</div>
                        <p class="text-gray-600 mt-2">' . $stat['label'] . '</p>
                    </div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20 bg-gray-50">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">About SIWS College</h2>
                <p class="text-xl text-gray-600 max-w-3xl mx-auto">Committed to academic excellence and holistic development since our establishment.</p>
            </div>
            
            <div class="grid md:grid-cols-2 gap-12 items-center">
                <div>
                    <img src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/92514b4b-22d4-40e5-ac8a-d2019a7d7e9c.png" alt="College campus aerial view showing multiple academic buildings, green spaces, and sports facilities" class="rounded-lg shadow-xl" />
                </div>
                <div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-6">Our Mission & Vision</h3>
                    <p class="text-gray-600 mb-6">
                        SIWS College is dedicated to providing quality education that empowers students to become innovative thinkers, 
                        responsible citizens, and future leaders. We strive to create an environment that fosters intellectual curiosity, 
                        critical thinking, and personal growth.
                    </p>
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-2 rounded-full mr-4">
                                <i class="fas fa-graduation-cap text-blue-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800">Quality Education</h4>
                                <p class="text-gray-600">Excellence in teaching and learning experiences</p>
                            </div>
                        </div>
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-2 rounded-full mr-4">
                                <i class="fas fa-users text-blue-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800">Student Support</h4>
                                <p class="text-gray-600">Comprehensive support services for all students</p>
                            </div>
                        </div>
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-2 rounded-full mr-4">
                                <i class="fas fa-globe text-blue-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800">Global Perspective</h4>
                                <p class="text-gray-600">Preparing students for global opportunities</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Courses Section -->
    <section id="courses" class="py-20 bg-white">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Our Courses & Programs</h2>
                <p class="text-xl text-gray-600">Comprehensive academic programs designed for success</p>
            </div>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php
                $courses = [
                    [
                        'icon' => 'fas fa-laptop-code',
                        'color' => 'blue',
                        'title' => 'Computer Science',
                        'description' => 'Bachelor\'s and Master\'s programs in computer science and information technology.'
                    ],
                    [
                        'icon' => 'fas fa-chart-line',
                        'color' => 'green',
                        'title' => 'Business Administration',
                        'description' => 'Comprehensive business programs with specialization options.'
                    ],
                    [
                        'icon' => 'fas fa-balance-scale',
                        'color' => 'purple',
                        'title' => 'Law Studies',
                        'description' => 'Professional law programs with practical training components.'
                    ],
                    [
                        'icon' => 'fas fa-flask',
                        'color' => 'red',
                        'title' => 'Science & Research',
                        'description' => 'Advanced science programs with research opportunities.'
                    ],
                    [
                        'icon' => 'fas fa-paint-brush',
                        'color' => 'yellow',
                        'title' => 'Arts & Design',
                        'description' => 'Creative arts programs fostering artistic expression.'
                    ],
                    [
                        'icon' => 'fas fa-heartbeat',
                        'color' => 'indigo',
                        'title' => 'Health Sciences',
                        'description' => 'Healthcare programs preparing future medical professionals.'
                    ]
                ];
                
                foreach ($courses as $course) {
                    echo '<div class="course-card bg-white rounded-lg shadow-md p-6 transition duration-300">
                        <div class="w-16 h-16 bg-' . $course['color'] . '-100 rounded-full flex items-center justify-center mb-6">
                            <i class="' . $course['icon'] . ' text-' . $course['color'] . '-600 text-2xl"></i>
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 mb-4">' . $course['title'] . '</h3>
                        <p class="text-gray-600 mb-6">' . $course['description'] . '</p>
                        <a href="course-details.php?course=' . urlencode($course['title']) . '" class="text-blue-600 font-semibold hover:text-blue-800">Learn More →</a>
                    </div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Facilities Section -->
    <section id="facilities" class="py-20 bg-gray-50">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Campus Facilities</h2>
                <p class="text-xl text-gray-600">State-of-the-art infrastructure for optimal learning</p>
            </div>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php
                $facilities = [
                    [
                        'image' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/25982a63-c309-408b-af88-f98c4c64ff27.png',
                        'title' => 'Library & Learning Resources',
                        'description' => 'Extensive collection of books, journals, and digital resources.'
                    ],
                    [
                        'image' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/98159da2-60c9-4793-9e48-3e56151de8a2.png',
                        'title' => 'Laboratories',
                        'description' => 'Fully equipped labs for science, computer, and research work.'
                    ],
                    [
                        'image' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/8949cfd3-5aa8-4420-b85b-1e3b7992ce55.png',
                        'title' => 'Sports Complex',
                        'description' => 'Comprehensive sports facilities for indoor and outdoor activities.'
                    ],
                    [
                        'image' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/5863f082-21db-4d51-ac34-3291aa1fe02c.png',
                        'title' => 'Auditorium',
                        'description' => 'Modern auditorium for events, seminars, and cultural activities.'
                    ],
                    [
                        'image' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/a642e2ab-02c0-4fcd-be5b-134fe79a5760.png',
                        'title' => 'Cafeteria',
                        'description' => 'Spacious cafeteria serving healthy and hygienic food options.'
                    ],
                    [
                        'image' => 'https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/c0e62acd-31b2-460e-a98b-f238e884df73.png',
                        'title' => 'Student Lounges',
                        'description' => 'Comfortable spaces for relaxation and group discussions.'
                    ]
                ];
                
                foreach ($facilities as $facility) {
                    echo '<div class="bg-white rounded-lg overflow-hidden shadow-md">
                        <img src="' . $facility['image'] . '" alt="' . $facility['title'] . '" class="w-full h-48 object-cover" />
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-gray-800 mb-3">' . $facility['title'] . '</h3>
                            <p class="text-gray-600">' . $facility['description'] . '</p>
                        </div>
                    </div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-20 bg-white">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Contact Us</h2>
                <p class="text-xl text-gray-600">Get in touch with SIWS College</p>
            </div>
            
            <div class="grid md:grid-cols-2 gap-12">
                <div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-6">College Information</h3>
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-3 rounded-full mr-4">
                                <i class="fas fa-map-marker-alt text-blue-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800">Address</h4>
                                <p class="text-gray-600">SIWS College Campus<br>Education Hub, Mumbai<br>Maharashtra, India</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-3 rounded-full mr-4">
                                <i class="fas fa-phone text-blue-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800">Phone</h4>
                                <p class="text-gray-600">+91 22 1234 5678<br>+91 22 9876 5432</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <div class="bg-blue-100 p-3 rounded-full mr-4">
                                <i class="fas fa-envelope text-blue-600"></i>
                            </div>
                            <div>
                                <h4 class="font-semibold text-gray-800">Email</h4>
                                <p class="text-gray-600">info@siwscollege.edu.in<br>admissions@siwscollege.edu.in</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-8">
                        <h4 class="font-semibold text-gray-800 mb-4">Follow Us</h4>
                        <div class="flex space-x-4">
                            <a href="#" class="bg-gray-100 p-3 rounded-full hover:bg-blue-100 transition duration-300">
                                <i class="fab fa-facebook-f text-blue-600"></i>
                            </a>
                            <a href="#" class="bg-gray-100 p-3 rounded-full hover:bg-blue-100 transition duration-300">
                                <i class="fab fa-twitter text-blue-400"></i>
                            </a>
                            <a href="#" class="bg-gray-100 p-3 rounded-full hover:bg-blue-100 transition duration-300">
                                <i class="fab fa-instagram text-pink-600"></i>
                            </a>
                            <a href="#" class="bg-gray-100 p-3 rounded-full hover:bg-blue-100 transition duration-300">
                                <i class="fab fa-linkedin-in text-blue-700"></i>
                            </a>
                            <a href="#" class="bg-gray-100 p-3 rounded-full hover:bg-blue-100 transition duration-300">
                                <i class="fab fa-youtube text-red-600"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-6">Send us a Message</h3>
                    <form action="process_contact.php" method="POST" class="space-y-6">
                        <div>
                            <label for="name" class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                            <input type="text" id="name" name="name"
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                   placeholder="Enter your full name" required>
                        </div>
                        
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input type="email" id="email" name="email"
                                   class="

