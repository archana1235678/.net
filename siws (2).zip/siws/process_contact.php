<?php
include 'includes/functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $message = sanitize_input($_POST['message']);

    if (empty($name) || empty($email) || empty($message)) {
        echo "All fields are required.";
        exit;
    }

    if (!validate_email($email)) {
        echo "Invalid email format.";
        exit;
    }

    // Example: Email logic (you can use mail() or PHPMailer)
    // mail("your-email@example.com", "Contact Form Submission", "Name: $name\nEmail: $email\nMessage:\n$message");

    echo "Thank you, $name! Your message has been sent.";
}
?>
