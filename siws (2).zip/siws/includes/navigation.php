 <?php
// Header/Navigation file for SIWS College website
?>
<header class="bg-white shadow-lg sticky top-0 z-50">
    <nav class="container mx-auto px-6 flex justify-between items-center py-4">
        <!-- Logo -->
        <a href="index.php" class="text-2xl font-bold text-blue-600">SIWS College</a>

        <!-- Navigation Links -->
        <ul class="hidden md:flex space-x-8 text-gray-700 font-medium">
            <li><a href="index.php#home" class="hover:text-blue-600">Home</a></li>
            <li><a href="index.php#about" class="hover:text-blue-600">About</a></li>
            <li><a href="index.php#courses" class="hover:text-blue-600">Courses</a></li>
            <li><a href="admission.php" class="hover:text-blue-600">Admissions</a></li>
            <li><a href="index.php#contact" class="hover:text-blue-600">Contact</a></li>
        </ul>

        <!-- Mobile Menu Button -->
        <button id="menu-btn" class="md:hidden text-gray-700 focus:outline-none">
            <i class="fas fa-bars text-2xl"></i>
        </button>
    </nav>

    <!-- Mobile Menu -->
    <div id="mobile-menu" class="hidden md:hidden bg-white shadow-lg">
        <ul class="flex flex-col space-y-4 p-6 text-gray-700 font-medium">
            <li><a href="index.php#home" class="hover:text-blue-600">Home</a></li>
            <li><a href="index.php#about" class="hover:text-blue-600">About</a></li>
            <li><a href="index.php#courses" class="hover:text-blue-600">Courses</a></li>
            <li><a href="admission.php" class="hover:text-blue-600">Admissions</a></li>
            <li><a href="index.php#contact" class="hover:text-blue-600">Contact</a></li>
        </ul>
    </div>

    <script>
        const menuBtn = document.getElementById('menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        menuBtn.addEventListener('click', () => {
            mobileMenu.classList.toggle('hidden');
        });
    </script>
</header>

