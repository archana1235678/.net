<?php
// Footer file for SIWS College website
?>
<footer class="bg-gray-800 text-white py-12">
    <div class="container mx-auto px-6">
        <div class="grid md:grid-cols-4 gap-8">
            <div>
                <h3 class="text-xl font-bold mb-6">SIWS College</h3>
                <p class="text-gray-400 mb-6">Excellence in education since 2005. Committed to shaping future leaders through quality education and holistic development.</p>
                <div class="flex space-x-4">
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-gray-400 hover:text-white"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
            
            <div>
                <h4 class="text-lg font-semibold mb-6">Quick Links</h4>
                <ul class="space-y-3">
                    <li><a href="index.php#home" class="text-gray-400 hover:text-white">Home</a></li>
                    <li><a href="index.php#about" class="text-gray-400 hover:text-white">About Us</a></li>
                    <li><a href="index.php#courses" class="text-gray-400 hover:text-white">Courses</a></li>
                    <li><a href="index.php#facilities" class="text-gray-400 hover:text-white">Facilities</a></li>
                    <li><a href="index.php#contact" class="text-gray-400 hover:text-white">Contact</a></li>
                </ul>
            </div>
            
            <div>
                <h4 class="text-lg font-semibold mb-6">Programs</h4>
                <ul class="space-y-3">
                    <li><a href="course-details.php?course=Computer%20Science" class="text-gray-400 hover:text-white">Undergraduate</a></li>
                    <li><a href="course-details.php?course=Business%20Administration" class="text-gray-400 hover:text-white">Postgraduate</a></li>
                    <li><a href="course-details.php?course=Science%20%26%20Research" class="text-gray-400 hover:text-white">Doctoral</a></li>
                    <li><a href="course-details.php?course=Arts%20%26%20Design" class="text-gray-40